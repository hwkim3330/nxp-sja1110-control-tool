/*
 * Original code: https://www.pixelbeat.org/programming/gcc/static_assert.html
 * Licensed under the GNU All-Permissive License.
 *
 * Modifications Copyright 2018-2024 NXP
 *
 * Copying and distribution of this file, with or without modification, are permitted in any medium without royalty,
 * provided the copyright notice and this notice are preserved. This file is offered as-is, without any warranty.
 *
 */
 
#ifndef CT_ASSERT_H
#define CT_ASSERT_H

 /**
 * @addtogroup  CLASS_ASSERT
 * @{
 *
 * @file        ct_assert.h
 *
 */

#define ASSERT_CONCAT_INNER(a, b) a##b
#define ASSERT_CONCAT_OUTER(a, b) ASSERT_CONCAT_INNER(a, b)
#define ct_assert(e) enum { ASSERT_CONCAT_OUTER(precompile_assert_, __COUNTER__) = (1/(!!(e))) }

/** @} */

#endif /* CT_ASSERT_H */
